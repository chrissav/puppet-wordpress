UPDATE
    wp_options
SET
    option_value = '{{ config.onelogin_idp_entity_id }}'
WHERE
    option_name = 'onelogin_saml_idp_entityid';

UPDATE
    wp_options
SET
    option_value = '{{ config.onelogin_sso_service_url }}'
WHERE
    option_name = 'onelogin_saml_idp_sso';