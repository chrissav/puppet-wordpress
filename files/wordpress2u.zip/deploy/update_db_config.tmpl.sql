UPDATE
    wp_options
SET
    option_value = '{{ config.theme_name }}'
WHERE
    option_name = 'current_theme';

UPDATE
    wp_options
SET
    option_value = '{{ config.site_url }}'
WHERE
    option_name IN('home', 'siteurl');
