UPDATE
    wp_options
SET
    option_value = REPLACE(option_value, 'http://{{ from_url }}', 'http://{{ to_url }}')
WHERE
    option_name IN('home', 'siteurl');

UPDATE
    wp_posts
SET
    guid = REPLACE(guid, 'http://{{ from_url }}', 'http://{{ to_url }}');

UPDATE
    wp_posts
SET
    post_content = REPLACE(post_content, 'http://{{ from_url }}', 'http://{{ to_url }}');
