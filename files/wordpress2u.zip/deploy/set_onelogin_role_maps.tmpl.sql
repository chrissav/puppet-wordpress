UPDATE
    wp_options
SET
    option_value = REPLACE(option_value, '-Prod-', '-Staging-')
WHERE
    option_name = 'onelogin_saml_role_mapping_administrator';

UPDATE
    wp_options
SET
    option_value = REPLACE(option_value, '-Prod-', '-Staging-')
WHERE
    option_name = 'onelogin_saml_role_mapping_editor';

UPDATE
    wp_options
SET
    option_value = REPLACE(option_value, '-Prod-', '-Staging-')
WHERE
    option_name = 'onelogin_saml_role_mapping_author';

UPDATE
    wp_options
SET
    option_value = REPLACE(option_value, '-Prod-', '-Staging-')
WHERE
    option_name = 'onelogin_saml_role_mapping_contributor';

UPDATE
    wp_options
SET
    option_value = REPLACE(option_value, '-Prod-', '-Staging-')
WHERE
    option_name = 'onelogin_saml_role_mapping_subscriber';
