import os
import re
from glob import glob
import datetime
import boto

from fabric.api import *
from fabric.colors import red, green, yellow, blue
from fabric.contrib.files import upload_template

from r2d2u.utils import (setup_fab_env, TempDir, render_template,
    generate_random_string, get_timestamp)
from r2d2u.fab.cloudformation import setup_fab_cloudformation
from r2d2u.fab.apache import *
from r2d2u.fab.utils import *
from r2d2u.fab.dbs import *

setup_fab_env('mktgorg', options=[
        ('init_db', bool),
        ('load_latest_snapshot', bool),
        ('migrate_site_from_url', str),
        ('disallow_robots', bool),
        ('http_auth_username', str),
        ('http_auth_password', str),
        ('maintenance_mode', bool),
        ('debug', bool),
    ],
    local_app_root_dir_prefix='www',
    app_config_sections=['core'])
# FIXME: Overload hosts if they are not in the CloudFormation stack already
if env.hosts:
    env.roledefs['www'] = env.hosts
setup_fab_cloudformation(roles=['www'])

env.config['debug'] = env.debug or env.config.get('debug', '').lower() == 'true'
env.config['upload_dir'] = '%s/wp-content/uploads' % env.app_root_dir
env.config['site_name'] = env.site_name
env.config['site_protocol'] = env.config.get('https_port', None) and 'https' or 'http'
env.config['site_url'] = '%s://%s' % (env.config['site_protocol'], env.config['site_host'])
env.config['enable_http_auth'] = env.http_auth_username and env.http_auth_password
for key in ('auth_key', 'secure_auth_key', 'logged_in_key', 'nonce_key',
            'auth_salt', 'secure_auth_salt', 'logged_in_salt', 'nonce_salt'):
    env.config[key] = generate_random_string(48, include=['letters', 'digits'])
env.config['newrelic_site_name'] = env.config['site_name'].replace('_', '-').replace('mktgorg-', '')
env.config['newrelic_env'] = env.env_type == 'prod' and 'production' or 'sandbox'
env.config['maintenance_mode'] = env.maintenance_mode
env.config['domain'] = env.domain

owner = '%s:www-data' % env.user

BACKUP_S3_BUCKET = '2tor-backups'
BACKUP_S3_PATH = '%s/dbs/staging' % env.app.replace('-', '_')

puts('Domain: %s' % env.domain)
puts('Environment: %s' % env.env_type)
puts('Debug: %s' % (env.config['debug'] and 'on' or 'off'))
puts('Enable HTTP Auth: %s' % (env.config['enable_http_auth'] and 'yes' or 'no'))
puts('Disallow Robots: %s' % (env.disallow_robots and 'yes' or 'no'))
puts('Load Latest Snapshot: %s' % (env.load_latest_snapshot and 'yes' or 'no'))
puts('Initialize DB: %s' % (env.init_db and 'yes' or 'no'))
puts('Maintenance Mode: %s' % (env.config['maintenance_mode'] and 'on' or 'off'))

@task
@roles('www')
def setup_config_file():
    puts(blue('Setting up Wordpress config...'))
    path = '%(app_root_dir)s/wp-config.php' % env
    upload_template('deploy/wp-config.php.tmpl', path, context={ 'config': env.config },
        use_jinja=True, backup=False, use_sudo=True)

@task
@roles('www')
def setup_apache():
    puts(blue('Setting up Apache...'))
    enable_apache_site(env.site_name, 'deploy/apache_vhost.tmpl', config=env.config)
    enable_apache_modules('rewrite headers expires proxy proxy_http')

# FIXME: Move to deploy
@task
@roles('www')
def disallow_all_robots():
    puts(red('Disallowing all search engine access...'))
    sudo('echo "User-agent: *\nDisallow: /" > %s/robots.txt' % env.app_root_dir)

@task
@roles('www')
def allow_all_robots():
    puts(red('Allowing all search engine access...'))
    sudo('echo "User-agent: *\nDisallow: " > %s/robots.txt' % env.app_root_dir)

@task
@parallel
@roles('www')
def deploy():
    deploy_code()
    deploy_config()
    puts(red('Restarting Apache...'))
    restart_apache()
    puts(green('Deployment complete. URL: %s' % env.config['site_url']))

@task
@roles('www')
def deploy_config():
    setup_config_file()
    setup_apache()
    if env.http_auth_username and env.http_auth_password:
        setup_apache_http_basic_auth(env.http_auth_username, env.http_auth_password, env.site_name)
    if env.disallow_robots:
        disallow_all_robots()
    else:
        allow_all_robots()

def get_latest_db_snapshot():
    filename_pattern = re.compile(r'^(\w{2,5})_(\w{2,5})_([\w_]+)_([\d\-T]+).sql.tar.gz$')
    timestamp_format = '%Y-%m-%dT%H-%M-%S'
    s3 = boto.connect_s3()
    bucket = s3.get_bucket(BACKUP_S3_BUCKET)
    snapshots, latest_snapshot = [], None
    for snapshot_key in bucket.list(prefix=BACKUP_S3_PATH):
        path, filename = os.path.split(snapshot_key.name)
        match = filename_pattern.match(filename)
        if match:
            inst_dept, prog_area = match.groups()[:2]
            timestamp = datetime.datetime.strptime(match.groups()[-1], timestamp_format)
            if env.inst_dept == inst_dept and env.prog_area == prog_area:
                snapshots.append((snapshot_key, path, filename, timestamp))
    if len(snapshots):
        latest_snapshot = sorted(snapshots, key=lambda s: s[-1], reverse=True)[0]
        puts(blue('Latest DB snapshot: {0}'.format(latest_snapshot[-1])))
    return latest_snapshot

@task
@roles('www')
def load_latest_db_snapshot():
    puts(blue('Loading latest DB snapshot...'))
    latest_snapshot = get_latest_db_snapshot()
    if not latest_snapshot:
        abort('Can\'t find a snapshot for this environment')
    init_db()
    snapshot_key, snapshot_path, snapshot_filename, snapshot_created = latest_snapshot
    puts(blue('Downloading snapshot ({0}) from S3...'.format(snapshot_filename)))
    snapshot_key.get_contents_to_filename(snapshot_filename)
    puts('Decompressing...')
    local('tar -xf %s' % snapshot_filename)
    db_dump_glob = '{0}_{1}_{2}_prod_cleansed_*.sql'.format(env.inst_dept,
        env.prog_area, env.app.replace('-', '_'))
    db_dump_filename = glob(db_dump_glob)[0]
    mysql_eval_path(env.config['db_name'], db_dump_filename, env.config['db_user'],
        env.config['db_password'], env.config['db_host'])
    local('rm -rf {0} {1}'.format(snapshot_filename, db_dump_filename))
    run_config_sql()
    if env.migrate_site_from_url:
        run_url_migration(env.migrate_site_from_url)

@task
@roles('www')
def load_latest_upload_content():
    puts(blue('Loading latest upload content...'))
    with settings(hide('running', 'warnings', 'stdout', 'stderr'), warn_only=True):
        chown(owner, env.config['upload_dir'], recurse=True)
        chmod('754', env.config['upload_dir'], recurse=True)
    rsync_result = None
    with settings(hide('running', 'stdout', 'stderr'), warn_only=True):
        rsync_result = rsync(env.config['upload_dir'] + '/', local_dir='uploads/*',
            ssh_opts='-o StrictHostKeyChecking=no',
            extra_opts=' --rsync-path="sudo rsync"', delete=True)
    if hasattr('return_code', rsync_result) and rsync_result.return_code not in (0, 23, 24):
        abort('rsync failed')

@task
@roles('www')
@runs_once
def load_latest_snapshot():
    load_latest_db_snapshot()
    load_latest_upload_content()
    set_onelogin_paths()
    set_onelogin_role_maps()

@task
@roles('www')
def init_db():
    config = env.config
    database, username, password, root_username, root_password, host = (config['db_name'],
        config['db_user'], config['db_password'], config['db_root_user'],
            config['db_root_password'], config['db_host'])
    drop_mysql_db(database, root_username, root_password, host)
    mysql_create_db(database, username, password, root_username, root_password, host)

@task
@roles('www')
def deploy_theme():
    puts(blue('Deploying theme code...'))
    remote_theme_dir = '%s/wp-content/themes/' % env.app_root_dir
    exclude = ('.git', '.gitignore', '.gitattributes', '.gitmodules',
        'README.md', 'readme.html')
    with settings(hide('running', 'warnings', 'stdout', 'stderr'), warn_only=True):
        rsync(remote_theme_dir, local_dir='wp-content/themes/*', exclude=exclude,
            ssh_opts='-o StrictHostKeyChecking=no',
            extra_opts=' --rsync-path="sudo rsync"', delete=True)

@task
@roles('www')
def deploy_code():
    with settings(hide('running', 'warnings', 'stdout', 'stderr'), warn_only=True):
        ensure_directory_exists(env.app_root_dir, owner=owner, perms='754')
        ensure_directory_exists(env.log_dir, owner=owner, perms='754')
    if not env.local:
        chown(owner, env.app_root_dir, recurse=True)
        exclude = ('.git', '.gitignore', '.gitattributes', '.gitmodules', 'env', 'deploy',
            'wp-content/uploads', 'README.md', 'log', '*.pyc', 'fabfile.py',
                'readme.html', 'requirements.txt')
        puts(blue('Deploying code...'))
        with settings(hide('running', 'warnings', 'stdout', 'stderr'), warn_only=True):
            rsync(env.app_root_dir, local_dir='./', exclude=exclude,
                ssh_opts='-o StrictHostKeyChecking=no',
                extra_opts=' --rsync-path="sudo rsync"', delete=True)
        deploy_theme()
        with settings(hide('running', 'stdout', 'stderr'), warn_only=True):
            chown(owner, env.app_root_dir, recurse=True)
            chmod('754', env.app_root_dir, recurse=True)

@task
@roles('www')
def run_config_sql():
    puts(blue('Setting up Wordpress DB config SQL...'))
    config = env.config
    with TempDir() as cwd:
        destination_path = '%s/config.sql' % cwd.path
        render_template('deploy/update_db_config.tmpl.sql', destination_path, { 'config': env.config })
        mysql_eval_path(config['db_name'], destination_path, config['db_user'],
            config['db_password'], config['db_host'])

@task
@roles('www')
def run_url_migration(from_url, to_url=None):
    puts(blue('Replacing URL references: {0}...'.format(from_url)))
    config = env.config
    if not to_url:
        to_url = config['site_host']
    with TempDir() as cwd:
        destination_path = '%s/migrate.sql' % cwd.path
        render_template('deploy/migrate_site.tmpl.sql', destination_path, locals())
        mysql_eval_path(config['db_name'], destination_path, config['db_user'],
            config['db_password'], config['db_host'])

@task
@roles('www')
def set_onelogin_paths():
    puts(blue('Setting up OneLogin paths...'))
    config = env.config
    if config.get('is_production') == "false":
        if config.get('onelogin_sso_service_url') and config.get('onelogin_idp_entity_id'):
            with TempDir() as cwd:
                destination_path = '%s/onelogin.sql' % cwd.path
                render_template('deploy/set_onelogin_paths.tmpl.sql', destination_path, locals())
                mysql_eval_path(config['db_name'], destination_path, config['db_user'],
                    config['db_password'], config['db_host'])
        else:
            puts(red('No OneLogin paths available to set.'))
    else:
        puts(blue('Production sites will not have OneLogin paths reset.'))

@task
@roles('www')
def set_onelogin_role_maps():
    puts(blue('Setting up OneLogin Role Maps...'))
    config = env.config
    if config.get('onelogin_sso_service_url') and config.get('onelogin_idp_entity_id'):
        if config.get('is_production') == "false":
            with TempDir() as cwd:
                destination_path = '%s/onelogin_roles.sql' % cwd.path
                render_template('deploy/set_onelogin_role_maps.tmpl.sql', destination_path, locals())
                mysql_eval_path(config['db_name'], destination_path, config['db_user'],
                    config['db_password'], config['db_host'])
        else:
            puts(red('Production role mappings are set as in snapshot and have not been changed.'))
